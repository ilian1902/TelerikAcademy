﻿namespace StudentClass
{
    public enum University
    {
        TechUni,
        SofiaUni,
        SoftUni,
        UASG,
    }
}
