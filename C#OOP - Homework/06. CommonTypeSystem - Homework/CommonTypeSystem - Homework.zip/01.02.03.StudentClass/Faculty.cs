﻿namespace StudentClass
{
    public enum Faculty
    {
        SF,
        TKO,
        KTT,
        EEP,
    }
}
