﻿namespace StudentClass
{
    public enum Speciality
    {
        Mathematics,
        Physics,
        Biology,
        Geology,
    }
}
